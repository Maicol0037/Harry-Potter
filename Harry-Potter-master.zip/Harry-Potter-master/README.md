# Harry Potter


## EXPECTO PATRONUM!

![text](https://user-images.githubusercontent.com/74983536/128005620-f7f44ba5-14d7-4329-abe4-0da9c93137e1.png)

THE HARRY POTTER GAME:

Consists of three parts-
1. Memory Game
2. Get your house
3. Treasure Hunt

https://user-images.githubusercontent.com/74983536/128004726-621922ec-0da7-44f0-a115-323c9c53a19b.mp4

Memory Game:

Swapping the cards and finding similar ones!


Get Your House:

Consists a series of question and at the end accordindly you are placed in your respective house


Treasure Hunt:

Toggle around with your wand and find the hidden treasures in dark.

![favicon](https://user-images.githubusercontent.com/74983536/128006266-426d2da9-b975-4d66-9327-46d9fcb464aa.png)

